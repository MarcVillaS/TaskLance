// backend/routes/applications.js
const express = require('express');
const router = express.Router();
const db = require('../db');

// Freelancer se postula
router.post('/apply', (req, res) => {
  const { user_id, project_id } = req.body;
  db.query('INSERT INTO applications (user_id, project_id) VALUES (?, ?)', [user_id, project_id], (err) => {
    if (err) return res.status(500).json({ error: 'Error al postularse' });
    res.json({ message: 'Postulación enviada' });
  });
});

// Listar candidaturas de un freelancer
router.get('/user/:user_id', (req, res) => {
  const userId = req.params.user_id;
  db.query(`
    SELECT a.*, p.name AS project_name, p.user_id AS empresa_id
    FROM applications a
    JOIN projects p ON a.project_id = p.id
    WHERE a.user_id = ?
  `, [userId], (err, results) => {
    if (err) return res.status(500).json({ error: 'Error al obtener candidaturas' });
    res.json(results);
  });
});

// Empresa responde a una candidatura
router.post('/respond', (req, res) => {
    const { application_id, status } = req.body;
  
    // Primero actualizar el estado de la candidatura
    db.query('UPDATE applications SET status = ? WHERE id = ?', [status, application_id], (err) => {
      if (err) return res.status(500).json({ error: 'Error al responder candidatura' });
  
      if (status === 'aceptado') {
        // Obtener user_id y project_id de la candidatura para insertar en user_projects
        db.query('SELECT user_id, project_id FROM applications WHERE id = ?', [application_id], (err, results) => {
          if (err) return res.status(500).json({ error: 'Error obteniendo datos para asignación' });
          if (results.length === 0) return res.status(404).json({ error: 'Candidatura no encontrada' });
  
          const { user_id, project_id } = results[0];
          db.query('INSERT IGNORE INTO user_projects (user_id, project_id) VALUES (?, ?)', [user_id, project_id], (err) => {
            if (err) return res.status(500).json({ error: 'Error asignando proyecto al freelancer' });
            return res.json({ message: `Candidatura ${status} y proyecto asignado` });
          });
        });
      } else {
        res.json({ message: `Candidatura ${status}` });
      }
    });
  });
  
  // Obtener candidaturas para proyectos de una empresa
router.get('/received/:empresa_id', (req, res) => {
    const empresaId = req.params.empresa_id;
    db.query(`
      SELECT a.id AS application_id, a.status, a.created_at, 
             u.id AS user_id, u.name AS freelancer_name,
             p.id AS project_id, p.name AS project_name
      FROM applications a
      JOIN users u ON a.user_id = u.id
      JOIN projects p ON a.project_id = p.id
      WHERE p.user_id = ?
      ORDER BY a.created_at DESC
    `, [empresaId], (err, results) => {
      if (err) return res.status(500).json({ error: 'Error al obtener candidaturas' });
      res.json(results);
    });
  });
  

module.exports = router;
