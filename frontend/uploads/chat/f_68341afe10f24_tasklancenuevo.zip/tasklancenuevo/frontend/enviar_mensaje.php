<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
include 'db.php';

$user_id = $_SESSION['user_id'];
$oferta_id = isset($_POST['oferta_id']) ? intval($_POST['oferta_id']) : 0;
$empresa_id = isset($_POST['empresa_id']) ? intval($_POST['empresa_id']) : 0;
$mensaje = trim($_POST['mensaje'] ?? '');

if ($oferta_id && $empresa_id && $mensaje !== '') {
    $sql = "INSERT INTO chat_messages (oferta_id, sender_type, sender_id, receiver_type, receiver_id, message) 
            VALUES (?, 'user', ?, 'empresa', ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$oferta_id, $user_id, $empresa_id, $mensaje]);
}
header("Location: chat.php?oferta_id=$oferta_id&empresa_id=$empresa_id");
exit;