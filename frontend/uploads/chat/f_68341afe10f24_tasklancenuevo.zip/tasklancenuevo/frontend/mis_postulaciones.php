<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
include '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT ofertas.nombre, ofertas.descripcion, ofertas.precio_hora, applications.status 
                       FROM applications 
                       JOIN ofertas ON applications.project_id = ofertas.id 
                       WHERE applications.user_id = ?");
$stmt->execute([$user_id]);
$postulaciones = $stmt->fetchAll();
?>

<h1>Mis postulaciones</h1>

<ul>
<?php foreach ($postulaciones as $p): ?>
    <li>
        <h3><?php echo $p['nombre']; ?></h3>
        <p><?php echo $p['descripcion']; ?></p>
        <p>Precio/h: <?php echo $p['precio_hora']; ?>€</p>
        <p>Estado: <?php echo $p['status']; ?></p>
    </li>
<?php endforeach; ?>
</ul>
