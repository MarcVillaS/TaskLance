<?php
session_start();

$pageTitle = "Iniciar Sesión";
$error = "";

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $error = "Por favor, completa todos los campos.";
    } else {
        // Buscar el usuario por email
        $stmt = $pdo->prepare("SELECT id, email, password FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            // Login correcto
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            header('Location: inicio_freelancer.php');
            exit;
        } else {
            $error = "Credenciales inválidas.";
        }
    }
}

include 'componentes/header.php';
?>

<style>
    .login-container {
        max-width: 400px;
        margin: 60px auto;
        background: #fff;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.08);
        text-align: center;
    }
    .login-container h1 {
        margin-bottom: 25px;
        color: #333;
    }
    .login-container input {
        width: 93%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 1em;
    }
    .login-container button {
        width: 100%;
        padding: 12px;
        background: #007bff;
        border: none;
        color: #fff;
        border-radius: 8px;
        font-size: 1em;
        font-weight: bold;
        cursor: pointer;
        transition: background 0.3s ease;
    }
    .login-container button:hover {
        background: #0056b3;
    }
    .error-message {
        color: #d9534f;
        margin-bottom: 15px;
        font-weight: bold;
    }
</style>

<div class="login-container">
    <h1>Iniciar sesión</h1>

    <?php if (!empty($error)) echo "<div class='error-message'>{$error}</div>"; ?>

    <form method="POST" novalidate>
        <input type="text" name="email" placeholder="Correo electrónico" required>
        <input type="password" name="password" placeholder="Contraseña" required>
        <button type="submit">Entrar</button>
    </form>
</div>