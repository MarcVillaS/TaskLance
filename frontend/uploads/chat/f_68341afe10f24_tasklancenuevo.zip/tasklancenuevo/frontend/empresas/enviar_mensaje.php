<?php
session_start();
if (!isset($_SESSION['empresa_id'])) {
    header("Location: login.php");
    exit;
}
include '../db.php';

$empresa_id = $_SESSION['empresa_id'];
$oferta_id = isset($_POST['oferta_id']) ? intval($_POST['oferta_id']) : 0;
$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
$mensaje = trim($_POST['mensaje'] ?? '');

if ($oferta_id && $user_id && $mensaje !== '') {
    $sql = "INSERT INTO chat_messages (oferta_id, sender_type, sender_id, receiver_type, receiver_id, message) 
            VALUES (?, 'empresa', ?, 'user', ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$oferta_id, $empresa_id, $user_id, $mensaje]);
}
header("Location: chat.php?oferta_id=$oferta_id&user_id=$user_id");
exit;