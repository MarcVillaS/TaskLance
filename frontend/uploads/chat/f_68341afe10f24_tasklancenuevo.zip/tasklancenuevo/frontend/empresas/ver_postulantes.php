<?php
session_start();

include '../db.php';

if (!isset($_SESSION['empresa_id'])) {
    header("Location: login.php");
    exit;
}

$oferta_id = $_GET['id'] ?? null;
if (!$oferta_id) {
    echo "Oferta no válida.";
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM ofertas WHERE id = ? AND empresa_id = ?");
$stmt->execute([$oferta_id, $_SESSION['empresa_id']]);
$oferta = $stmt->fetch();

if (!$oferta) {
    echo "No tienes permiso para ver esta oferta.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['postulacion_id'], $_POST['nuevo_estado'])) {
    $postulacion_id = $_POST['postulacion_id'];
    $nuevo_estado = $_POST['nuevo_estado'];

    if (in_array($nuevo_estado, ['aceptado', 'rechazado', 'pendiente'])) {
        $update = $pdo->prepare("UPDATE postulaciones SET estado = ? WHERE id = ?");
        $update->execute([$nuevo_estado, $postulacion_id]);
        header("Location: ver_postulantes.php?id=" . $oferta_id);
        exit;
    }
}

$stmt = $pdo->prepare("
    SELECT p.id, u.id as user_id, u.username, p.fecha_postulacion, p.estado
    FROM postulaciones p
    JOIN users u ON p.user_id = u.id
    WHERE p.oferta_id = ?
");
$stmt->execute([$oferta_id]);
$postulantes = $stmt->fetchAll();

include 'componentes/header.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Postulantes para <?= htmlspecialchars($oferta['nombre']) ?></title>
    <style>
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: #f4f4f4; }
        header {
            background: #007bff;
            color: #fff;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h1 {
            margin: 0;
            font-size: 1.5em;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            margin-left: 20px;
            font-weight: bold;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .container {
            padding: 20px 30px;
            max-width: 900px;
            margin: 20px auto;
            background: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            border-radius: 6px;
        }
        h2 {
            margin-top: 0;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #007bff;
            color: white;
        }
        tbody tr:nth-child(even) {
            background: #f9f9f9;
        }
        tbody tr:hover {
            background: #e6f0ff;
        }
        form {
            margin: 0;
        }
        button {
            padding: 6px 12px;
            margin-right: 5px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-weight: bold;
            color: white;
            transition: background-color 0.3s ease;
        }
        button.aceptar {
            background-color: #28a745;
        }
        button.aceptar:hover {
            background-color: #218838;
        }
        button.rechazar {
            background-color: #dc3545;
        }
        button.rechazar:hover {
            background-color: #c82333;
        }
        button.deshacer {
            background-color: #ffc107;
            color: #333;
        }
        button.deshacer:hover {
            background-color: #e0a800;
        }
        .chat-btn {
            background-color: #17a2b8;
            color: #fff;
            margin-right: 0;
            margin-top: 4px;
            padding: 6px 14px;
            border-radius: 3px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.2s;
        }
        .chat-btn:hover {
            background-color: #117a8b;
        }
        .estado {
            text-transform: capitalize;
            font-weight: bold;
        }
        .estado.aceptado {
            color: #28a745;
        }
        .estado.pendiente {
            color: #ffc107;
        }
        .estado.rechazado {
            color: #dc3545;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Postulantes para: <?= htmlspecialchars($oferta['nombre']) ?></h2>

    <?php if (count($postulantes) === 0): ?>
        <p>No hay postulantes aún.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Freelancer</th>
                    <th>Fecha de postulación</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($postulantes as $postulante): ?>
                    <tr>
                        <td><?= htmlspecialchars($postulante['username']) ?></td>
                        <td><?= htmlspecialchars($postulante['fecha_postulacion']) ?></td>
                        <td class="estado <?= htmlspecialchars($postulante['estado']) ?>"><?= htmlspecialchars($postulante['estado']) ?></td>
                        <td>
                            <?php if ($postulante['estado'] === 'pendiente'): ?>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="postulacion_id" value="<?= $postulante['id'] ?>" />
                                    <input type="hidden" name="nuevo_estado" value="aceptado" />
                                    <button class="aceptar" type="submit">Aceptar</button>
                                </form>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="postulacion_id" value="<?= $postulante['id'] ?>" />
                                    <input type="hidden" name="nuevo_estado" value="rechazado" />
                                    <button class="rechazar" type="submit">Rechazar</button>
                                </form>
                            <?php elseif ($postulante['estado'] === 'rechazado'): ?>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="postulacion_id" value="<?= $postulante['id'] ?>" />
                                    <input type="hidden" name="nuevo_estado" value="pendiente" />
                                    <button class="deshacer" type="submit">Deshacer rechazo</button>
                                </form>
                            <?php elseif ($postulante['estado'] === 'aceptado'): ?>
                                <a class="chat-btn" href="chat.php?oferta_id=<?= $oferta_id ?>&user_id=<?= $postulante['user_id'] ?>">Chatear</a>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <a class="back-link" href="dashboard.php">&larr; Volver</a>
</div>

</body>
</html>