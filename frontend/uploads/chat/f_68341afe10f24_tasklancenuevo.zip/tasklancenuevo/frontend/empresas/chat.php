<?php
session_start();
if (!isset($_SESSION['empresa_id'])) {
    header("Location: login.php");
    exit;
}
include '../db.php';

$empresa_id = $_SESSION['empresa_id'];
$oferta_id = isset($_GET['oferta_id']) ? intval($_GET['oferta_id']) : 0;
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

// Info del freelancer
$stmt = $pdo->prepare("SELECT username, avatar FROM users WHERE id=?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Info de la oferta/proyecto
$stmt = $pdo->prepare("SELECT nombre FROM ofertas WHERE id=?");
$stmt->execute([$oferta_id]);
$oferta = $stmt->fetch(PDO::FETCH_ASSOC);

// Info de la empresa (tú)
$stmt = $pdo->prepare("SELECT nombre FROM empresas WHERE id=?");
$stmt->execute([$empresa_id]);
$empresa = $stmt->fetch(PDO::FETCH_ASSOC);

// Marcar mensajes como leídos al entrar al chat para la empresa
$stmt = $pdo->prepare("
    SELECT MAX(id) as max_id 
    FROM chat_messages 
    WHERE oferta_id=? AND receiver_type='empresa' AND receiver_id=? AND sender_type='user' AND sender_id=?
");
$stmt->execute([$oferta_id, $empresa_id, $user_id]);
$maxId = $stmt->fetchColumn();
if ($maxId) {
    $stmt = $pdo->prepare("
        INSERT INTO chat_leidos (user_id, oferta_id, empresa_id, leido_msg_id)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE leido_msg_id=VALUES(leido_msg_id)
    ");
    // Para empresa, guardamos el user_id como 0 (o si quieres una tabla aparte para empresas, pero así es más sencillo)
    $stmt->execute([0, $oferta_id, $empresa_id, $maxId]);
}

include 'componentes/header.php';
?>

<style>
body {
    background: #f3f6fb;
}
.chat-box {
    max-width: 660px;
    margin: 40px auto;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 32px rgba(0,0,0,0.09);
    padding: 0 0 20px 0;
    display: flex;
    flex-direction: column;
    height: 80vh; /* Fija la altura para que el chat no crezca indefinidamente */
}
.chat-header {
    background: #007bff;
    color: #fff;
    padding: 24px 32px;
    border-radius: 12px 12px 0 0;
    margin-bottom: 0;
}
.chat-header .proyecto {
    font-size: 1.15em;
    margin-bottom: 3px;
    font-weight: 600;
}
.chat-header .info {
    font-size: 0.97em;
    opacity: 0.93;
}
#mensajes {
    flex: 1;
    overflow-y: auto;
    padding: 32px 32px 10px 32px;
    background: #f8fafb;
    display: flex;
    flex-direction: column;
    gap: 16px;
    scroll-behavior: smooth;
    max-height: 60vh; /* Limita la altura máxima del área de mensajes */
    min-height: 0;
}
.mensaje-burbuja {
    max-width: 65%;
    padding: 12px 16px;
    border-radius: 16px;
    background: #eaf2fb;
    align-self: flex-start;
    position: relative;
    margin-bottom: 2px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    word-break: break-word;
}
.mensaje-burbuja.empresa {
    background: #007bff;
    color: white;
    align-self: flex-end;
}
.mensaje-burbuja .meta {
    font-size: 0.8em;
    color: #8ba0b5;
    margin-top: 4px;
    text-align: right;
}
.mensaje-burbuja.empresa .meta {
    color: #e6e6e6;
}
.mensaje-burbuja .autor-nombre {
    font-weight: 600;
    margin-right: 6px;
    font-size: 0.93em;
    color: #007bff;
}
.mensaje-burbuja.empresa .autor-nombre {
    color: #fff;
}
.enviar-mensaje {
    display: flex;
    gap: 12px;
    padding: 18px 32px 0 32px;
    background: #fff;
    border-radius: 0 0 12px 12px;
    border-top: 1px solid #f0f0f0;
}
.enviar-mensaje textarea {
    flex: 1;
    resize: none;
    min-height: 32px;
    max-height: 120px;
    border-radius: 8px;
    border: 1px solid #c6d2e8;
    padding: 10px;
    font-size: 1em;
}
.enviar-mensaje button {
    background: #007bff;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 0 24px;
    font-weight: bold;
    cursor: pointer;
    font-size: 1em;
    transition: background 0.2s;
}
.enviar-mensaje button:hover {
    background: #0056b3;
}
@media (max-width: 700px) {
    .chat-box { max-width: 99vw; }
    .chat-header, .enviar-mensaje, #mensajes { padding-left: 10px; padding-right: 10px;}
}
</style>

<div class="chat-box">
    <div class="chat-header">
        <div class="proyecto">
            Chat con el freelancer <b><?php echo htmlspecialchars($user['username']); ?></b>
        </div>
        <div class="info">
            Proyecto: <b><?php echo htmlspecialchars($oferta['nombre']); ?></b>
        </div>
    </div>

    <div id="mensajes">
        <!-- Aquí se cargarán los mensajes vía AJAX -->
    </div>

    <form action="enviar_mensaje.php" method="POST" class="enviar-mensaje" id="form-chat">
        <input type="hidden" name="oferta_id" value="<?php echo $oferta_id; ?>">
        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
        <textarea name="mensaje" required placeholder="Escribe tu mensaje..." maxlength="1000"></textarea>
        <button type="submit">Enviar</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script>
function cargarMensajes() {
    $.get('obtener_mensajes.php', {
        oferta_id: <?php echo $oferta_id; ?>,
        user_id: <?php echo $user_id; ?>,
        empresa_id: <?php echo $empresa_id; ?>,
        tipo: 'empresa'
    }, function(html) {
        let $mensajes = $('#mensajes');
        $mensajes.html(html);
        $mensajes.scrollTop($mensajes[0].scrollHeight); // SIEMPRE al final
    });
}
$(function() {
    cargarMensajes();
    setInterval(cargarMensajes, 3000);
    $('#form-chat').on('submit', function(e) {
        e.preventDefault();
        $.post($(this).attr('action'), $(this).serialize(), function() {
            cargarMensajes();
            $('#form-chat textarea').val('');
        });
    });
});
</script>
<?php include 'componentes/footer.php'; ?>