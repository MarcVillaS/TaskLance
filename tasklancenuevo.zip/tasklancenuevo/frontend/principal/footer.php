<footer style="margin-top:40px; background:#222; color:#fff; padding:18px 0; text-align:center; font-size:1em;">
    &copy; <?= date("Y") ?> TaskLance. Todos los derechos reservados.
</footer>
</body>
</html>